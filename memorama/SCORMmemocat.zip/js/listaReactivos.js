
//Primer conjunto de tarjetas
// la primer posicion le va corresponder la primera posicion del arreglo respuestas
//ejemplo:
// en el arreglo de preguntas colocariamos:
//"¿como te llamas?",
//"¿de donde eres?" 
//y en el arreglo de respuestas:
//"francisco",
//"Mèxico"
var rutaspreguntas=[
/* 
"./imagenes/perro1.jpg",
"./audios/audio1_i1u2t10.mp3",
"./video/gato.mp4",
"CUAED"
 */

"./imagenes/perro1.jpg",
"./imagenes/perro2.jpg",
"./imagenes/perro3.jpg",
"./imagenes/perro4.jpg",
"./imagenes/perro5.jpg",
/* 
"./video/gato.mp4",
"./video/pato.mp4",
"./video/patol.mp4",
*/
/* 
"./audios/audio1_i1u2t10.mp3",
"./audios/audio3_i1u2t10.mp3",
"./audios/audio5_i1u2t10.mp3",
*/

"Hola ",
"Adios",
"Buenos dias ",
"¿Cómo estas?",
"Felicidades",


    ]
var rutarespuestas=[
/* 
"./imagenes/perro1.jpg",
"./audios/audio1_i1u2t10.mp3",
"./video/gato.mp4",
"CUAED"
*/
 
 
"./imagenes/perro1.jpg",
"./imagenes/perro2.jpg",
"./imagenes/perro3.jpg",
"./imagenes/perro4.jpg",
"./imagenes/perro5.jpg",
/* 
"./video/gato.mp4",
"./video/pato.mp4",
"./video/patol.mp4",
*/
/*
"./audios/audio1_i1u2t10.mp3",
"./audios/audio3_i1u2t10.mp3",
"./audios/audio5_i1u2t10.mp3",
*/

"Hola ",
"Adios",
"Buenos dias ",
"¿Cómo estas?",
"Felicidades",
]